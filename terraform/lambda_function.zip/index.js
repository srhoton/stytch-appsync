exports.handler = async (event) => {
  console.log('Event:', JSON.stringify(event, null, 2));
        
  // Extract JWT claims from the authorizer context
  const claims = event.requestContext?.authorizer?.jwt?.claims || {};
        
  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      status: 'success',
      message: 'Authentication successful',
      timestamp: new Date().toISOString(),
      user: {
        sub: claims.sub || 'unknown',
        email: claims.email || null,
        claims: claims
      }
    })
  };
};
